using CSV, DataFrames, Random, Plots, Statistics,StatsPlots

POP_SIZE = 200
N_GEN = 200
MUT_PROB = 0.3
N_MUT = 1
TOURNAMENT_SIZE = 20
MAX_STAGNATION = 15
ELITE_COUNT = 15



function load_lookup_table(path::String)
    df = CSV.read(path, DataFrame, types=Dict(:features => String))
    sample_feature = df.features[1]
    n_bits = length(sample_feature)
    table = Dict{BitVector, Float64}()
    for row in eachrow(df)
        bin = lpad(row.features, n_bits, '0')  # << in teoria ora già corretto
        vec = BitVector([c == '1' for c in bin])
        table[vec] = row.loss
    end
    return table, n_bits
end


function get_fitness_lookup(ind, table::Dict{BitVector, Float64})
    key = BitVector(ind)
    if haskey(table, key)
        return table[key] + 0.0001 * count(x -> x == true, key)
    else
        return 2.0
    end
end

function initialize_population(pop_size, n_bits)
    return [rand(Bool, n_bits) for _ in 1:pop_size]
end

function tournament_selection(pop, fitness, k)
    selected = Vector{Vector{Bool}}()
    for _ in 1:length(pop)
        candidates = rand(1:length(pop), k)
        best_idx = argmin(fitness[candidates])
        push!(selected, copy(pop[candidates[best_idx]]))
    end
    return selected
end

function two_point_crossover(pop)
    offspring = copy(pop)
    shuffle!(offspring)
    for i in 1:2:(length(pop)-1)
        p1, p2 = offspring[i], offspring[i+1]
        pt1, pt2 = sort(rand(1:length(p1), 2))
        p1[pt1:pt2], p2[pt1:pt2] = p2[pt1:pt2], p1[pt1:pt2]
    end
    return offspring
end

function mutation!(pop, mut_prob, n_flips)
    for ind in pop
        for _ in 1:n_flips
            i = rand(1:length(ind))
            if rand() < mut_prob
                ind[i] = !ind[i]
            end
        end
    end
end

function mean_hamming(pop)
    total = 0
    count = 0
    for i in 1:length(pop), j in i+1:length(pop)
        total += sum(pop[i] .!= pop[j])
        count += 1
    end
    return count == 0 ? 0.0 : total / count
end

function benchmark_ga(filepath::String; n_runs=10)
    table, N_BITS = load_lookup_table(filepath)
    best_rmse_vals = Float64[]
    active_features = Int[]
    best_bitstrings = String[]

    all_min_fitness = Vector{Vector{Float64}}()
    all_mean_fitness = Vector{Vector{Float64}}()

    for run in 1:n_runs
        println("\n🔁 Run $run/$n_runs")
        population = initialize_population(POP_SIZE, N_BITS)
        best = deepcopy(population[1])
        best_fitness = get_fitness_lookup(best, table)
        stagnation = 0
        mut_prob = MUT_PROB

        min_fitness_run = Float64[]
        mean_fitness_run = Float64[]

        for gen in 1:N_GEN
            fitness = [get_fitness_lookup(ind, table) for ind in population]
            current_best_idx = argmin(fitness)
            current_best = population[current_best_idx]
            current_best_fitness = fitness[current_best_idx]

            if current_best_fitness < best_fitness
                best = deepcopy(current_best)
                best_fitness = current_best_fitness
                stagnation = 0
                mut_prob = MUT_PROB
            else
                stagnation += 1
            end

            push!(min_fitness_run, current_best_fitness)  # 👈 Best fitness at this generation
            push!(mean_fitness_run, mean(fitness))         # 👈 Mean fitness at this generation

            selected = tournament_selection(population, fitness, TOURNAMENT_SIZE)
            offspring = two_point_crossover(selected)
            mutation!(offspring, mut_prob, N_MUT)
            sorted_pop = sort(collect(zip(population, fitness)), by = x -> x[2])
            elites = [copy(x[1]) for x in sorted_pop[1:ELITE_COUNT]]
            population = offspring[1:(POP_SIZE - ELITE_COUNT)]
            append!(population, elites)
        end

        final_rmse = round(get_fitness_lookup(best, table), digits=6)
        bitstr = join(map(x -> x ? "1" : "0", best))
        println(" Run $run best individual: RMSE = $final_rmse | Active features: $(sum(best))")
        
        push!(best_rmse_vals, final_rmse)
        push!(active_features, sum(best))
        push!(best_bitstrings, bitstr)

        push!(all_min_fitness, min_fitness_run)
        push!(all_mean_fitness, mean_fitness_run)
    end

    # 📊 Plot results for each run
    for run in 1:n_runs
        p = plot(
            all_min_fitness[run], label="Best Fitness ", lw=2,
            xlabel="Generation", ylabel="RMSE", title="Fitness Progress "
        )
        plot!(p, all_mean_fitness[run], label="Mean Fitness ", lw=2, linestyle=:dash)
        display(p)
    end

    # 📋 Create final table
    results_df = DataFrame(
        Run = 1:n_runs,
        Best_RMSE = best_rmse_vals,
        Active_Features = active_features,
        Bitstring = best_bitstrings
    )

    println("\n Summary of best individuals per run:")
    println(results_df)

    # 📊 Summary statistics
    avg_rmse = mean(best_rmse_vals)
    std_rmse = std(best_rmse_vals)

    println("\n Summary statistics over $n_runs runs:")
    println("Average Best RMSE: ", round(avg_rmse, digits=6))
    println("Standard Deviation of Best RMSE: ", round(std_rmse, digits=6))

    # 📁 Save results
    CSV.write("benchmark_results.csv", results_df)
    println(" Results table saved to 'benchmark_results.csv'")
end



function run_ga_lookup(filepath::String)
    table, N_BITS = load_lookup_table(filepath)

    if N_BITS > 10
        N_MUT = max(1, round(Int, 0.1 * N_BITS))  
    else 
        N_MUT = 0

    end

    population = initialize_population(POP_SIZE, N_BITS)

    best = deepcopy(population[1])
    best_fitness = get_fitness_lookup(best, table)
    mean_f, min_f, divs = Float64[], Float64[], Float64[]
    stagnation = 0
    mut_prob = MUT_PROB
    α = 0.9
    prev_mean_rmse = nothing

    for gen in 1:N_GEN
        fitness = [get_fitness_lookup(ind, table) for ind in population]
        current_best_idx = argmin(fitness)
        current_best = population[current_best_idx]
        current_best_fitness = fitness[current_best_idx]

        if current_best_fitness < best_fitness
            best = deepcopy(current_best)
            best_fitness = current_best_fitness
            stagnation = 0
            mut_prob = MUT_PROB
        else
            stagnation += 1
        end

        raw_mean_rmse = mean(fitness)
        smooth_mean_rmse = isnothing(prev_mean_rmse) ? raw_mean_rmse : α * prev_mean_rmse + (1 - α) * raw_mean_rmse
        prev_mean_rmse = smooth_mean_rmse

        println("Gen $gen | Best RMSE: $(round(best_fitness, digits=6)) | Mean RMSE: $(round(smooth_mean_rmse, digits=6))")

        push!(mean_f, smooth_mean_rmse)
        push!(min_f, minimum(fitness))
        push!(divs, mean_hamming(population))

        """if stagnation ≥ MAX_STAGNATION
            println("🔁 Stagnazione: reset parziale alla generazione $gen")
            mut_prob *= 1.2
            stagnation = 0
        end"""

        

        
        fitness = [get_fitness_lookup(ind, table) for ind in population]
        sorted_pop = sort(collect(zip(population, fitness)), by = x -> x[2])
        elites = [copy(x[1]) for x in sorted_pop[1:ELITE_COUNT]]
        selected = tournament_selection(population, fitness, TOURNAMENT_SIZE)
        offspring = two_point_crossover(selected)
        mutation!(offspring, mut_prob, N_MUT)
        population = offspring[1:(POP_SIZE - ELITE_COUNT)]
        append!(population, elites)

    end

    bitstr = join(map(x -> x ? "1" : "0", best))
    println("\n Best individual:")
    println("Bitstring: $bitstr")
    println("Final RMSE (lookup): ", round(best_fitness, digits=6))
    println("Active features: ", sum(best))

    p = plot(mean_f, label="Mean Fitness (RMSE)", lw=2, color=:blue)
    plot!(p, min_f, label="Best fitness (RMSE)", lw=2, color=:red)
    xlabel!("Iterations")
    ylabel!("RMSE")
    title!("Fitness evolution")
    display(p)
end

function is_local_optimum(vec::BitVector, table::Dict{BitVector, Float64})
    val = get_fitness_lookup(vec, table)
    for i in 1:length(vec)
        neighbor = copy(vec)
        neighbor[i] = !neighbor[i]
        neighbor_val = haskey(table, neighbor) ? get_fitness_lookup(neighbor, table) : Inf
        if neighbor_val < val
            return false
        end
    end
    return true
end



function visualize_local_optima(filepath::String)
    table = load_lookup_table(filepath)[1]
    points = collect(keys(table))
    
    rmse_all = [table[b] + 0.0001 * count(x -> x == true, b) for b in points]  # 👈 aggiungiamo già la penalty!
    active_all = [count(==(true), b) for b in points]
    
    # Local minima: penalized value
    local_minima = [(b, get_fitness_lookup(b, table), count(==(true), b)) for b in points if is_local_optimum(b, table)]
    sort!(local_minima, by = x -> x[2])  # sort by penalized RMSE

    x_vals = [a for (b, penal, a) in local_minima]
    y_vals = [penal for (b, penal, a) in local_minima]

    scatter(active_all, rmse_all, label="All points", alpha=0.3, color=:gray, markersize=3)
    scatter!(x_vals, y_vals, label="Local minima", color=:red, markershape=:star5, markersize=6)
    xlabel!("Active features")
    ylabel!("RMSE")
    title!("All points + Local minima (penalized)")
    println("\nLocal minima found: $(length(local_minima))")

    for (bit, penalized_val, a) in local_minima
        println("Bitstring: $(join(map(x -> x ? 1 : 0, bit))) | Penalized RMSE: $(round(penalized_val, digits=6)) | Active features: $a")
    end

    display(current())
end


function visualize_heatmap_distribution(filepath::String)
    table, _ = load_lookup_table(filepath)
    points = collect(keys(table))
    sorted_points = sort(points, by = x -> count(x))
    n_rows = 32
    n_cols = cld(length(sorted_points), n_rows)
    grid_vals = fill(NaN, n_rows, n_cols)
    for (i, vec) in enumerate(sorted_points)
        row = mod1(i, n_rows)
        col = cld(i, n_rows)
        grid_vals[row, col] = get_fitness_lookup(vec, table)
    end
    heatmap(grid_vals, xlabel="Colonna", ylabel="Riga", title="Heatmap Fitness Penalizzata (lookup table)", colorbar_title="RMSE")
    display(current())
end


run_ga_lookup("C:/Users/giovy/Desktop/scopiazziamo/log_reg_feature.csv")
#benchmark_ga("C:/Users/giovy/Desktop/scopiazziamo/svm_feature.csv", n_runs=10)


#visualize_local_optima("C:/Users/giovy/Desktop/scopiazziamo/svm_feature.csv")
#benchmark_ga("C:/Users/giovy/Desktop/scopiazziamo/log_reg_feature.csv", n_runs=10)

